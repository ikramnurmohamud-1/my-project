import { useState, useEffect } from 'react';
import './Profile.css';

function Profile() {
  const [stats, setStats] = useState({
    totalNotes: 0,
    categories: {},
  });

  useEffect(() => {
    const savedNotes = localStorage.getItem('notes');
    if (savedNotes) {
      const notes = JSON.parse(savedNotes);
      const categoryCount = {};

      notes.forEach((note) => {
        const category = note.category || 'Uncategorized';
        categoryCount[category] = (categoryCount[category] || 0) + 1;
      });

      setStats({
        totalNotes: notes.length,
        categories: categoryCount,
      });
    }
  }, []);

  return (
    <div className="profile-page">
      <div className="profile-wrapper">
        <div className="profile-container">
        <div className="profile-header">
          <div className="profile-avatar">
            <span className="avatar-icon">👤</span>
          </div>
          <h2>Your Profile</h2>
        </div>

        <div className="profile-stats">
          <div className="stat-card">
            <h3>Total Notes</h3>
            <p className="stat-value">{stats.totalNotes}</p>
          </div>

          <div className="stat-card">
            <h3>Categories</h3>
            <div className="categories-list">
              {Object.keys(stats.categories).length === 0 ? (
                <p className="no-data">No categories yet</p>
              ) : (
                Object.entries(stats.categories).map(([category, count]) => (
                  <div key={category} className="category-item">
                    <span className="category-name">{category}</span>
                    <span className="category-count">{count}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
}

export default Profile;
