import { useState } from 'react';
import './NoteCard.css';

function NoteCard({ note, deleteNote, updateNote }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(note.title);
  const [editedContent, setEditedContent] = useState(note.content);

  const handleSave = () => {
    if (editedTitle.trim() || editedContent.trim()) {
      updateNote(note.id, {
        title: editedTitle.trim() || 'Untitled',
        content: editedContent.trim(),
      });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedTitle(note.title);
    setEditedContent(note.content);
    setIsEditing(false);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="note-card" style={{ backgroundColor: note.color }}>
      {isEditing ? (
        <div className="note-edit">
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            className="edit-title"
          />
          <textarea
            value={editedContent}
            onChange={(e) => setEditedContent(e.target.value)}
            className="edit-content"
            rows="4"
          />
          <div className="edit-actions">
            <button onClick={handleCancel} className="cancel-edit-btn">
              Cancel
            </button>
            <button onClick={handleSave} className="save-edit-btn">
              Save
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="note-header">
            <h3 className="note-title">{note.title}</h3>
            <span className="note-category">{note.category}</span>
          </div>
          <p className="note-content">{note.content}</p>
          <div className="note-footer">
            <span className="note-date">{formatDate(note.createdAt)}</span>
            <div className="note-actions">
              <button
                onClick={() => setIsEditing(true)}
                className="edit-btn"
                aria-label="Edit note"
              >
                ✏️
              </button>
              <button
                onClick={() => deleteNote(note.id)}
                className="delete-btn"
                aria-label="Delete note"
              >
                🗑️
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default NoteCard;
