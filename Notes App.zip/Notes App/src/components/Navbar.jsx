import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar({ darkMode, toggleDarkMode }) {
  return (
    <nav className="navbar">
      <div className="navbar-content">
        <h1 className="navbar-title">Notes App</h1>
        <div className="navbar-links">
          <Link to="/" className="nav-link">Notes</Link>
          <Link to="/profile" className="nav-link">Profile</Link>
          <button
            onClick={toggleDarkMode}
            className="dark-mode-toggle"
            aria-label="Toggle dark mode"
          >
            {darkMode ? '☀️' : '🌙'}
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
