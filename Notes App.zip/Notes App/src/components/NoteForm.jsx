import { useState } from 'react';
import './NoteForm.css';

const CATEGORIES = ['Personal', 'Work', 'Ideas', 'Todo', 'Other'];
const COLORS = ['#ffb3ba', '#bae1ff', '#baffc9', '#ffffba', '#ffdfba', '#e0bbff'];

function NoteForm({ addNote }) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('Personal');
  const [color, setColor] = useState(COLORS[0]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title.trim() || content.trim()) {
      addNote({
        title: title.trim() || 'Untitled',
        content: content.trim(),
        category,
        color,
      });
      setTitle('');
      setContent('');
      setCategory('Personal');
      setColor(COLORS[0]);
      setIsOpen(false);
    }
  };

  return (
    <div className="note-form-container">
      {!isOpen ? (
        <button onClick={() => setIsOpen(true)} className="add-note-button">
          + New Note
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="note-form">
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="note-input"
            autoFocus
          />
          <textarea
            placeholder="Take a note..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="note-textarea"
            rows="4"
          />
          <div className="note-options">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="category-select"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            <div className="color-picker">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`color-option ${color === c ? 'selected' : ''}`}
                  style={{ backgroundColor: c }}
                  onClick={() => setColor(c)}
                  aria-label={`Select color ${c}`}
                />
              ))}
            </div>
          </div>
          <div className="form-actions">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="cancel-button"
            >
              Cancel
            </button>
            <button type="submit" className="submit-button">
              Add Note
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default NoteForm;
