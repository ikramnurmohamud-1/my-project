# Notes App

A feature-rich note-taking application built with React, featuring dark mode, categories, and local storage persistence.

## Features

- **Create, Edit, and Delete Notes**: Full CRUD functionality for managing your notes
- **Search Functionality**: Search notes by title or content in real-time
- **Categories**: Organize notes with predefined categories (Personal, Work, Ideas, Todo, Other)
- **Color Labels**: Assign different colors to your notes for visual organization
- **Dark Mode**: Toggle between light and dark themes with persistence
- **Local Storage**: All notes are automatically saved to your browser's local storage
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Routing**: Multiple pages using React Router (Notes and Profile)

## Technologies Used

- **React**: UI library with hooks (useState, useEffect)
- **React Router DOM**: Client-side routing
- **Vite**: Fast build tool and development server
- **CSS3**: Modern styling with CSS custom properties for theming
- **localStorage**: Browser storage for data persistence

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Navigate to the project directory:
```bash
cd "Notes App"
```

2. Install dependencies (already done):
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and visit the URL shown in the terminal (usually http://localhost:5173)

## Usage

### Adding a Note
1. Click the "+ New Note" button
2. Enter a title and content
3. Select a category from the dropdown
4. Choose a color by clicking on one of the color options
5. Click "Add Note" to save

### Editing a Note
1. Click the edit icon (✏️) on any note card
2. Modify the title or content
3. Click "Save" to update or "Cancel" to discard changes

### Deleting a Note
1. Click the delete icon (🗑️) on any note card
2. The note will be immediately removed

### Searching Notes
1. Type in the search bar at the top
2. Notes will be filtered in real-time based on title or content
3. Click the "×" button to clear the search

### Dark Mode
1. Click the sun/moon icon in the navigation bar
2. The theme preference is automatically saved

## Project Structure

```
src/
├── components/
│   ├── Navbar.jsx          # Navigation bar with dark mode toggle
│   ├── Navbar.css
│   ├── NoteCard.jsx        # Individual note display component
│   ├── NoteCard.css
│   ├── NoteForm.jsx        # Form for creating new notes
│   ├── NoteForm.css
│   ├── SearchBar.jsx       # Search input component
│   └── SearchBar.css
├── pages/
│   ├── Notes.jsx           # Main notes page
│   ├── Notes.css
│   ├── Profile.jsx         # Profile/stats page
│   └── Profile.css
├── App.jsx                 # Main app component with routing
├── App.css                 # Global styles and theme variables
└── main.jsx                # Entry point
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint

## Features Implemented

All requirements have been successfully implemented:

- ✅ useState for state management
- ✅ useEffect for side effects (localStorage sync)
- ✅ localStorage for data persistence
- ✅ Props for component communication
- ✅ Multiple pages with routing (Notes, Profile)
- ✅ Add, delete, and view notes
- ✅ Search by title or content
- ✅ Categories for organization
- ✅ Color labels for visual distinction
- ✅ Dark mode toggle with persistence

## License

This project is open source and available for educational purposes.
